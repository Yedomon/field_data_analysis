##--Script for GGEBiplotGUI analysis
##--By Yedomon Ange Bovys Zoclanclounon | twitter: @AngeBovys27
##--20.01.2021
##--National Institute of Agricultural Science | Department of Genomics |RDA | Republic of South Korea


## Set the working directory

setwd("C:/Users/ange_/Downloads/Pearl_Millet_Zn_Fe_Project/GGEBiplotGUI")

## Loading library

library(GGEBiplotGUI)

## Data

data_fe = read.csv("data_fe_gge_gui.csv", sep = ";", dec = ",", row.names = 1)


View(data_fe)


GGEBiplot(Data = data_fe)
